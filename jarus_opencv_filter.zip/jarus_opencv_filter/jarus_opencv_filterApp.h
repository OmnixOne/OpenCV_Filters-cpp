/***************************************************************
 * Name:      jarus_opencv_filterApp.h
 * Purpose:   Defines Application Class
 * Author:    jarus (surajsingh999898@gmail.com)
 * Created:   2019-10-07
 * Copyright: jarus ()
 * License:
 **************************************************************/

#ifndef JARUS_OPENCV_FILTERAPP_H
#define JARUS_OPENCV_FILTERAPP_H

#include <wx/app.h>

class jarus_opencv_filterApp : public wxApp
{
    public:
        virtual bool OnInit();
};

#endif // JARUS_OPENCV_FILTERAPP_H
